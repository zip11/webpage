
console.log("Hello,World!");
