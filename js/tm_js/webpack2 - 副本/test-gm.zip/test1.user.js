// ==UserScript==
// @name         测试脚本2
// @namespace    https://bbs.tampermonkey.net.cn/
// @version      0.1.0
// @description  try to take over the world!
// @author       You
// @match        https://bbs.tampermonkey.net.cn/
// ==/UserScript==

alert('ok4');
